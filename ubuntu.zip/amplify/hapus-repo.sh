#!/usr/bin/env bash

hapus_repo(){
  aws codecommit delete-repository --repository-name $1 > /dev/null 2>&1
}

for i in {1..16}; do
  now=$(sed -n ${i}p region.txt)
  aws configure set region $now
  hapus_repo test
  hapus_repo test1
  echo "==> region $now"
done

