#!/usr/bin/env bash

for i in {1..16}; do
  now=$(sed -n ${i}p region.txt)
  aws configure set region $now
  ./sup0.sh
  echo "==> region $now"
done

