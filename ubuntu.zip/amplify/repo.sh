#!/usr/bin/env bash

create_repo(){
  aws codecommit create-repository --repository-name $1 > /dev/null 2>&1
}

for i in {1..16}; do
  now=$(sed -n ${i}p region.txt)
  aws configure set region $now
  create_repo test
  ./code.sh
  echo "==> region $now"
done

