echo "
rm -rf .git
git init >/dev/null 2>&1
git config --global user.email heroku@gmail.com
git config --global user.name heroku
" > oke
chmod +x oke
./oke
