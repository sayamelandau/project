### Sample Application made with react

- Available at `https://master.d19tgz4vpyd5.amplifyapp.com/` (AWS Amplify)

- Custom domain at `https://funwithreact.web.app/`

### Deploy React on AWS Amplify

- https://levelup.gitconnected.com/deploy-react-and-aws-amplify-1db36c625d73

### Show push notifications in React

- https://levelup.gitconnected.com/show-push-notifications-in-react-449949e98e01?gi=4b7e9b97b54b

### Fade In/Fade Out text in React

- https://levelup.gitconnected.com/fade-in-out-text-in-react-fa8fc7a2a0b1

### For using notifications

- Enter the value in REACT_APP_VAPID_KEY
- Inside the firebaseInit.js, place your firebase config
- Inside the firebase-messaging-sw.js, place your firebase config

### Pieces Snippets

- Calling APIs in React
https://aseem.pieces.cloud/?p=61fa45af76
