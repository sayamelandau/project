#!/usr/bin/env bash

for i in {0..9}; do
  APPID=$(aws amplify list-apps --output json  --query 'apps['$i'].appId'| tr -d '"' 2> /dev/null)
  STAT=$(aws amplify list-jobs --app-id $APPID --branch-name master --query 'jobSummaries[0].status'| tr -d '"' 2> /dev/null)
  if [[ ($STAT != "RUNNING" ) && ( $STAT != "PENDING") ]]; 
  then
    aws amplify start-job --app-id $APPID --branch-name master --job-type RELEASE
  else
    echo "job status = $STAT"
  fi
done

