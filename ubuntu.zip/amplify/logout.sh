rm ~/.aws/config
rm ~/.aws/credentials

